package com.christopherhield.ml_kit_sample;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.label.ImageLabel;
import com.google.mlkit.vision.label.ImageLabeler;
import com.google.mlkit.vision.label.ImageLabeling;
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Locale;

// https://developers.google.com/ml-kit/vision/image-labeling/android

// Test images on Pixel 3XL

public class MainActivity extends AppCompatActivity {
    static final int REQUEST_IMAGE_GALLERY = 1;

    private Bitmap currentImage;
    private static final String TAG = "MainActivity";

    static final float MIN_CONFIDENCE_LEVEL = 0.75f;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void addPhoto(View v) {
        checkPerm();
    }

    ////////////
    private void checkPerm() {
        if (ContextCompat.checkSelfPermission(MainActivity.this,
                android.Manifest.permission.WRITE_EXTERNAL_STORAGE) !=
                PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(MainActivity.this, new String[]{
                    Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
        } else {
            openGallery();
        }
    }

    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permission, @NonNull int[] grantedResult) {
        super.onRequestPermissionsResult(requestCode, permission, grantedResult);
        if (requestCode == REQUEST_IMAGE_GALLERY) {
            if (grantedResult.length > 0 && grantedResult[0] == PackageManager.PERMISSION_GRANTED) {
                Log.i("TAG", "Permission Granted");
                openGallery();
            } else {
                Log.i("TAG", "Permission Denied");
                Toast.makeText(this, "WRITE_EXTERNAL_STORAGE denied. Exiting app.", Toast.LENGTH_LONG).show();
                finish();
            }
        }
    }
    ////////////


    private void openGallery() {
        Intent photoPickerIntent = new Intent(Intent.ACTION_PICK);
        photoPickerIntent.setType("image/*");
        startActivityForResult(photoPickerIntent, REQUEST_IMAGE_GALLERY);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_IMAGE_GALLERY && resultCode == RESULT_OK) {
            try {
                processGallery(data);
            } catch (Exception e) {
                Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show();
                e.printStackTrace();
            }
        }
    }


    public void processGallery(Intent data) throws IOException {
        Uri imageUri = data.getData();
        if (imageUri == null) {
            Toast.makeText(this, "Error: no image", Toast.LENGTH_LONG).show();
            return;
        }

        final InputStream imageStream = getContentResolver().openInputStream(imageUri);
        final Bitmap selectedImage = BitmapFactory.decodeStream(imageStream);

        Bitmap reduced = Bitmap.createScaledBitmap(
                selectedImage,
                (int) (selectedImage.getWidth() * 0.5),
                (int) (selectedImage.getHeight() * 0.5),
                false);

        ((ImageView) findViewById(R.id.imageView)).setImageBitmap(reduced);
        currentImage = reduced;

    }

    public void doAnalyze(View v) {
        InputImage image;
        image = InputImage.fromBitmap(currentImage, 0);

        ImageLabelerOptions options = new ImageLabelerOptions.Builder()
                .setConfidenceThreshold(MIN_CONFIDENCE_LEVEL)
                .build();

        ImageLabeler labeler = ImageLabeling.getClient(options);

        labeler.process(image)
                .addOnSuccessListener(new OnSuccessListener<List<ImageLabel>>() {
                    @Override
                    public void onSuccess(List<ImageLabel> imageLabels) {
                        Log.d(TAG, "onSuccess: ");
                        StringBuilder sb = new StringBuilder();
                        for (ImageLabel label : imageLabels) {
                            String text = label.getText() + ":";
                            float confidence = label.getConfidence();
                            sb.append(
                                    String.format(Locale.getDefault(),"      %-15s%.3f%n", text, confidence));
                        }
                        showResults(sb.toString());
                    }
                });
    }

    private void showResults(String text) {

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setPadding(50,20,0,0);
        tv.setTextColor(Color.BLACK);
        tv.setTextSize(16.0f);
        tv.setTypeface(Typeface.MONOSPACE);

        builder.setView(tv);

        builder.setTitle("Picture Analysis:");
        AlertDialog dialog = builder.create();
        dialog.show();
    }
}
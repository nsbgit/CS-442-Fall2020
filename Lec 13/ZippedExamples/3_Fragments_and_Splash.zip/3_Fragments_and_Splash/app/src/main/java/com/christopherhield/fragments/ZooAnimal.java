package com.christopherhield.fragments;

import androidx.annotation.NonNull;



public class ZooAnimal implements Comparable<ZooAnimal> {

    private String name;
    private String latin;
    private String height;
    private String weight;
    private String distribution;
    private String details;
    private String habitat;
    private String wild_diet;
    private String zoo_diet;

    ZooAnimal(String nameIn, String latinIn, String heightIn, String weightIn, String distributionIn, String habitatIn, String wild_dietIn, String zoo_dietIn, String detailsIn) {
        name = nameIn;
        latin = latinIn;
        height = heightIn;
        weight = weightIn;
        distribution = distributionIn;
        details = detailsIn;
        habitat = habitatIn;
        wild_diet = wild_dietIn;
        zoo_diet = zoo_dietIn;
    }

    // Accessors
    String getWild_diet() {
        return wild_diet;
    }

    String getZoo_diet() {
        return zoo_diet;
    }

    String getHabitat() {
        return habitat;
    }

    String getHeight() {
        return height;
    }

    String getWeight() {
        return weight;
    }

    String getDistribution() {
        return distribution;
    }

    String getName() {
        return name;
    }

    String getDetails() {
        return details;
    }

    String getLatin() {
        return latin;
    }

    @Override
    public int compareTo(@NonNull ZooAnimal o) {
        return name.compareTo(o.name);
    }
}

package com.christopherhield.fragments;

import java.util.ArrayList;
import java.util.Collections;


class ZooManager {

    // list used to hold all existing ZooAnimal objects
    private static ArrayList<ZooAnimal> allAnimals = new ArrayList<>();


    // Add a new animal to the list of animals
    static void addNew(String nameIn, String latinIn, String heightIn, String weightIn,
                       String distributionIn, String habitatIn, String wild_dietIn, String zoo_dietIn, String detailsIn) {
        ZooAnimal za = new ZooAnimal(nameIn, latinIn, heightIn, weightIn, distributionIn, habitatIn, wild_dietIn, zoo_dietIn, detailsIn);
        allAnimals.add(za);
        Collections.sort(allAnimals);
    }

    // Clear the list of animals
    static void clear() {
        allAnimals.clear();
    }

    // Accessor method to get/return a ZooAnimal from the allAnimals list
    static ZooAnimal get(int idx) {
        return allAnimals.get(idx);
    }

    // Return a string array of all ZooAnimal names
    static String[] getAllNames() {
            String[] names = new String[allAnimals.size()];
        for (int i = 0; i < allAnimals.size(); i++) {
            names[i] = allAnimals.get(i).getName();
        }
        return names;
    }
}

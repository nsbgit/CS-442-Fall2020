package com.example.biotest;


import android.app.admin.DevicePolicyManager;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;

import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {

    //This needs USE_BIOMETRIC permission!

    private TextView resultsText;
    private TextView promptText;
    private ImageView fingerprintIcon;
    private Button button;
    private static final int SETTINGS_REQ = 1234;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        resultsText = findViewById(R.id.results);
        promptText = findViewById(R.id.textView3);
        button = findViewById(R.id.button);
        fingerprintIcon = findViewById(R.id.imageView);

        tryFingerprint();

    }

    // Called when fingerprint icon is clicked
    public void doFingerprint(View v) {
        tryFingerprint();
    }


    private void tryFingerprint() {
        if (checkBiometricSupport()) {
            fingerprintReady();
        } else {
            fingerprintNotReady();
        }
    }


    private Boolean checkBiometricSupport() {

        BiometricManager biometricManager = BiometricManager.from(this);
        switch (biometricManager.canAuthenticate()) {
            case BiometricManager.BIOMETRIC_SUCCESS:
                return true;
            case BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE:
                resultsText.setText(R.string.no_hw);
                return false;
            case BiometricManager.BIOMETRIC_ERROR_HW_UNAVAILABLE:
                resultsText.setText(R.string.bio_unavail);
                return false;
            case BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED:
                resultsText.setText(R.string.finger_none);
                return false;
            default:
                resultsText.setText(R.string.unspec_error);
                return false;
        }

    }


    private void fingerprintNotReady() {
        fingerprintIcon.setVisibility(View.INVISIBLE);
        promptText.setVisibility(View.INVISIBLE);
        button.setVisibility(View.VISIBLE);
    }

    public void fingerprintReady() {

        //Create a thread pool with a single thread
        Executor newExecutor = Executors.newSingleThreadExecutor();

        //Start listening for authentication events
        //onAuthenticationError is called when a fatal error occurs
        //onAuthenticationSucceeded is called when a fingerprint is matched
        //onAuthenticationFailed is called when the fingerprint does not match

        BiometricPrompt myBiometricPrompt = new BiometricPrompt(this, newExecutor,

            new BiometricPrompt.AuthenticationCallback() {

            @Override
            //Called when auth. results in a cancel or error
            public void onAuthenticationError(final int errorCode, @NonNull final CharSequence errString) {
                super.onAuthenticationError(errorCode, errString);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {

                        if (errorCode == BiometricPrompt.ERROR_NEGATIVE_BUTTON) {
                            resultsText.setText(R.string.finger_cxl);
                        } else {
                            resultsText.setText(errString);
                        }
                    }
                });
            }


            @Override
            // Called when a fingerprint is matched successfully
            public void onAuthenticationSucceeded(@NonNull BiometricPrompt.AuthenticationResult result) {
                super.onAuthenticationSucceeded(result);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        resultsText.setText(R.string.finger_ok);
                        button.setVisibility(View.INVISIBLE);
                    }
                });
            }


            @Override
            // Called when the fingerprint does not match
            public void onAuthenticationFailed() {
                super.onAuthenticationFailed();
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        resultsText.setText(R.string.finger_bad);
                    }
                });
            }
        });


        //Create the BiometricPrompt instance
        BiometricPrompt.PromptInfo promptInfo = new BiometricPrompt.PromptInfo.Builder()
                .setTitle("Fingerprint sign in")
                .setSubtitle(" ")
                .setDescription("Sign in using your finger print to see your accounts")
                .setNegativeButtonText("Cancel")
                .build();

        myBiometricPrompt.authenticate(promptInfo);

    }


    public void goToSettings(View v) {
        Intent intent = new Intent(DevicePolicyManager.ACTION_SET_NEW_PASSWORD);
        startActivityForResult(intent, SETTINGS_REQ);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        // Nothing is returned here - we'll just try fingerprint checks again
        resultsText.setText("");
        tryFingerprint();
    }
}
package com.christopherhield.broadcastandreceive;

import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    // Send broadcast messages - received by receivers
    public static final String SAMPLE_BROADCAST_TYPE_A = "A Type Message";
    public static final String SAMPLE_BROADCAST_TYPE_B = "B Type Message";
    public static final String DATA_EXTRA = "DATA_EXTRA";

    private EditText textA, textB;

    private SampleReceiver sampleReceiver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textA = findViewById(R.id.editText);
        textB = findViewById(R.id.editText2);

        // Create a receiver object
        sampleReceiver = new SampleReceiver(this);

        IntentFilter filter1 = new IntentFilter(SAMPLE_BROADCAST_TYPE_A);
        IntentFilter filter2 = new IntentFilter(SAMPLE_BROADCAST_TYPE_B);

        registerReceiver(sampleReceiver, filter1);
        registerReceiver(sampleReceiver, filter2);
    }

    @Override
    protected void onDestroy() {
        // Don't forget to unregister!
        unregisterReceiver(sampleReceiver);
        super.onDestroy();
    }

    public void sendA(View v) {
        String txt = textA.getText().toString();
        if (txt.isEmpty())
            return;

        // Send broadcast msg to service
        Intent intent = new Intent();
        intent.setAction(SAMPLE_BROADCAST_TYPE_A);
        intent.putExtra(DATA_EXTRA, txt);
        sendBroadcast(intent);
    }

    public void sendB(View v) {
        String txt = textB.getText().toString();
        if (txt.isEmpty())
            return;

        // Send broadcast msg to service
        Intent intent = new Intent();
        intent.setAction(SAMPLE_BROADCAST_TYPE_B);
        String reversed = new StringBuilder(txt).reverse().toString();
        intent.putExtra(DATA_EXTRA, reversed);
        sendBroadcast(intent);
    }

}

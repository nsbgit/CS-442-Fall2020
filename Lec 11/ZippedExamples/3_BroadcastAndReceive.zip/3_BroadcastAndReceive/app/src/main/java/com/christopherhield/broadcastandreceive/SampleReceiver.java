package com.christopherhield.broadcastandreceive;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.widget.Toast;

public class SampleReceiver extends BroadcastReceiver {

    private static final String TAG = "SampleReceiver";
    private MainActivity mainActivity;

    public SampleReceiver(MainActivity mainActivity) {
        this.mainActivity = mainActivity;
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        // This method is called when a broadcast is made that
        // this receiver is registered to receive

        if (intent == null || intent.getAction() == null)
            return;

        // Check the "action" type of the message received
        switch (intent.getAction()) {

            case MainActivity.SAMPLE_BROADCAST_TYPE_A:
                String value = "";
                if (intent.hasExtra(MainActivity.DATA_EXTRA))
                    value = intent.getStringExtra(MainActivity.DATA_EXTRA);
                Toast.makeText(mainActivity, "Receiver has a message type A: " + value, Toast.LENGTH_LONG).show();
                break;

            case MainActivity.SAMPLE_BROADCAST_TYPE_B:
                String rValue = "";
                if (intent.hasExtra(MainActivity.DATA_EXTRA))
                    rValue = intent.getStringExtra(MainActivity.DATA_EXTRA);
                Toast.makeText(mainActivity, "Receiver has a message type B: " + rValue, Toast.LENGTH_LONG).show();
                break;

            default:
                Log.d(TAG, "onReceive: Unexpected broadcast: " + intent.getAction());
        }
    }

}

package com.christopherhield.broadcastandreceive;

import androidx.annotation.NonNull;

import java.io.Serializable;
import java.util.Locale;

// MUST be Serializable since it will be an intent extra
public class Fruit implements Serializable {

    private String name;
    private String color;
    private double cost;

    Fruit(String name, String color, double cost) {
        this.name = name;
        this.color = color;
        this.cost = cost;
    }

    @NonNull
    @Override
    public String toString() {
        return name + " is " + color + " and costs " +
                String.format(Locale.getDefault(),"$%.2f", cost);
    }
}

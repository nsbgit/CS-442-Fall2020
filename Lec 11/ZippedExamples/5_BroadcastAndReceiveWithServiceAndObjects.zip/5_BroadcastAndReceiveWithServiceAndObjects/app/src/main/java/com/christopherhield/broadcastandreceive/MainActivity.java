package com.christopherhield.broadcastandreceive;

import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    static final String FRUIT_FROM_SERVICE = "FRUIT_FROM_SERVICE";
    static final String MESSAGE_FROM_SERVICE = "MESSAGE_FROM_SERVICE";
    static final String FRUIT_DATA = "FRUIT_DATA";
    static final String COUNT_DATA = "COUNT_DATA";
    static final String MESSAGE_DATA = "MESSAGE_DATA";

    private SampleReceiver sampleReceiver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        /// Create some data for the service to use
        ArrayList<Fruit> fruitList = new ArrayList<>();
        fruitList.add(new Fruit("Apple", "Red", 0.89));
        fruitList.add(new Fruit("Pear", "Green", 1.10));
        fruitList.add(new Fruit("Banana", "Yellow", 0.99));
        fruitList.add(new Fruit("Orange", "Orange", 1.15));
        fruitList.add(new Fruit("Eggplant", "Purple", 1.79));
        fruitList.add(new Fruit("Watermelon", "Green", 2.99));
        fruitList.add(new Fruit("Cherry", "Red", 1.10));
        fruitList.add(new Fruit("Persimmon", "Orange", 1.99));
        fruitList.add(new Fruit("Lemon", "Yellow", 0.59));
        fruitList.add(new Fruit("Blueberry", "Blue", 1.59));

        /// Start the service (pass it the fruit list)
        Intent intent = new Intent(MainActivity.this, FruitService.class);
        intent.putExtra("FRUIT_LIST", fruitList);
        startService(intent);

        IntentFilter filter1 = new IntentFilter(FRUIT_FROM_SERVICE);
        IntentFilter filter2 = new IntentFilter(MESSAGE_FROM_SERVICE);

        sampleReceiver = new SampleReceiver(this);

        registerReceiver(sampleReceiver, filter1);
        registerReceiver(sampleReceiver, filter2);
    }


    public void stopButton(View v) {
        stopService();
    }

    private void stopService() {
        Intent intent = new Intent(MainActivity.this, FruitService.class);
        stopService(intent);
    }

    @Override
    protected void onDestroy() {
        // Unregister the receiver!
        unregisterReceiver(sampleReceiver);

        // Stop the service
        stopService();

        super.onDestroy();
    }

}

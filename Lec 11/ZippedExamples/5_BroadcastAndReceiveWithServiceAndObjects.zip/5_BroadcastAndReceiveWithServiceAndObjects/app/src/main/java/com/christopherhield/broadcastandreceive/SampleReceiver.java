package com.christopherhield.broadcastandreceive;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.widget.TextView;

import java.util.Locale;

class SampleReceiver extends BroadcastReceiver {

    private static final String TAG = "SampleReceiver";
    private MainActivity mainActivity;

    public SampleReceiver(MainActivity mainActivity) {
        this.mainActivity = mainActivity;
    }

    @Override
    public void onReceive(Context context, Intent intent) {

        String action = intent.getAction();
        if (action == null)
            return;

        switch (action) {
            case MainActivity.FRUIT_FROM_SERVICE:
                Fruit newFruit = null;
                int count = 0;

                if (intent.hasExtra(MainActivity.FRUIT_DATA))
                    newFruit = (Fruit) intent.getSerializableExtra(MainActivity.FRUIT_DATA);

                if (intent.hasExtra(MainActivity.COUNT_DATA))
                    count = intent.getIntExtra(MainActivity.COUNT_DATA, 0);

                if (newFruit != null) {
                    ((TextView) mainActivity.findViewById(R.id.textView)).setText(
                            String.format(Locale.getDefault(),
                                    "%d)  %s", count, newFruit.toString()));
                }
                break;

            case MainActivity.MESSAGE_FROM_SERVICE:
                String data = "";
                if (intent.hasExtra(MainActivity.MESSAGE_DATA))
                    data = intent.getStringExtra(MainActivity.MESSAGE_DATA);
                ((TextView) mainActivity.findViewById(R.id.textView)).setText(data);
                break;

            default:
                Log.d(TAG, "onReceive: Unknown broadcast received");
        }
    }
}

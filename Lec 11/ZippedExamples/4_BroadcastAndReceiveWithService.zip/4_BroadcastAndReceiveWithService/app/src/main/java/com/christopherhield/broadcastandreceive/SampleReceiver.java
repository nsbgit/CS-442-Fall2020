package com.christopherhield.broadcastandreceive;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.widget.TextView;

class SampleReceiver extends BroadcastReceiver {

    private static final String TAG = "SampleReceiver";
    private MainActivity mainActivity;

    public SampleReceiver(MainActivity mainActivity) {
        this.mainActivity = mainActivity;
    }

    @Override
    public void onReceive(Context context, Intent intent) {

        String action = intent.getAction();
        if (action == null)
            return;

        if (MainActivity.MESSAGE_FROM_SERVICE.equals(action)) {
            String data = "";
            if (intent.hasExtra(CountService.DATA_EXTRA))
                data = intent.getStringExtra(CountService.DATA_EXTRA);

            ((TextView) mainActivity.findViewById(R.id.textView)).setText(data);

        } else {
            Log.d(TAG, "onReceive: Unknown broadcast received");
        }
    }
}

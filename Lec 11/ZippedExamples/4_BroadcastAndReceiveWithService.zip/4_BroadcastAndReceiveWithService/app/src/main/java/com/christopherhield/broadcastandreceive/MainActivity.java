package com.christopherhield.broadcastandreceive;

import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    public static final String MESSAGE_FROM_SERVICE = "MESSAGE_FROM_SERVICE";

    private SampleReceiver sampleReceiver;
    private Button button;
    private TextView textView;
    private boolean serviceIsRunning = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button = findViewById(R.id.button);
        textView = findViewById(R.id.serviceMessage);

        sampleReceiver = new SampleReceiver(this);
        IntentFilter filter = new IntentFilter(MESSAGE_FROM_SERVICE);
        registerReceiver(sampleReceiver, filter);

        startService();
    }

    private void startService() {
        Intent intent = new Intent(MainActivity.this, CountService.class);
        startService(intent);
        serviceIsRunning = true;
        textView.setText(R.string.running);
    }

    private void stopService() {
        Intent intent = new Intent(MainActivity.this, CountService.class);
        stopService(intent);
        textView.setText(R.string.not_running);

    }

    public void toggleService(View v) {
        if (serviceIsRunning) {
            stopService();
            serviceIsRunning = false;
            button.setText(R.string.start_service);
        } else {
            startService();
            serviceIsRunning = true;
            button.setText(R.string.stop_service);

        }

    }

    @Override
    protected void onDestroy() {
        // Unregister your receiver
        unregisterReceiver(sampleReceiver);

        // Stop the service
        stopService();

        super.onDestroy();
    }

}

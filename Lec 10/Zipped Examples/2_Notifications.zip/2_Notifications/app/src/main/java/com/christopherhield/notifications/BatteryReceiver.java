package com.christopherhield.notifications;

import android.app.Notification;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.media.RingtoneManager;
import android.os.BatteryManager;
import android.os.Vibrator;
import android.util.Log;

import androidx.core.app.NotificationCompat;

public class BatteryReceiver extends BroadcastReceiver {

    private static final String TAG = "BatteryReceiver";
    public static boolean notificationDisplayed = false;
    private MainActivity mainActivity;
    public static final int BATTERY_NOTIFICATION_ID = 12345;
    public static final String NOTIFICATION_CANCELLED = "NOTIFICATION_CANCELLED";

    public BatteryReceiver() {
        super();
    }

    public void setActivity(MainActivity mainActivity) {
        this.mainActivity = mainActivity;
    }

    public void onReceive(Context context, Intent intent) {

        String action = intent.getAction();
        if (action == null)
            return;
        Log.d(TAG, "onReceive: " + action);

        if (action.equals(Intent.ACTION_BATTERY_CHANGED)) {
            int chargeLevel = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);

            Log.d(TAG, "onReceive: " + chargeLevel);
            if (chargeLevel <= 50) {
                if (!notificationDisplayed) {
                    notificationDisplayed = true;
                    makeBatteryNotification(chargeLevel);
                    Vibrator vibe = (Vibrator) context.getSystemService(Context.VIBRATOR_SERVICE);
                    if (vibe != null)
                        vibe.vibrate(750);
                }
            } else {
                if (notificationDisplayed) {
                    mainActivity.getNotificationManager().cancel(BATTERY_NOTIFICATION_ID);
                    notificationDisplayed = false;
                }
            }
        } else if (action.equals(NOTIFICATION_CANCELLED)) {
            notificationDisplayed = false;
        }
    }

    private void makeBatteryNotification(int level) {

        Intent resultIntent = new Intent(mainActivity, ResultActivity.class);
        resultIntent.putExtra("LEVEL", level);
        PendingIntent resultPendingIntent =
                PendingIntent.getActivity(mainActivity, BATTERY_NOTIFICATION_ID, resultIntent, PendingIntent.FLAG_UPDATE_CURRENT);

        Intent clearIntent = new Intent(mainActivity, BatteryReceiver.class);
        clearIntent.setAction(NOTIFICATION_CANCELLED);
        PendingIntent clearPendingIntent =
                PendingIntent.getBroadcast(mainActivity, BATTERY_NOTIFICATION_ID, clearIntent, PendingIntent.FLAG_ONE_SHOT);

        NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(mainActivity, MainActivity.CHANNEL_ID)
                .setContentIntent(resultPendingIntent)
                .setAutoCancel(true)
                .setSmallIcon(R.drawable.battery)
                .setContentTitle("Battery Status")
                .setContentText("Battery is at " + level + "%")
                .setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION))
                .setLights(Color.MAGENTA, 1000, 300)
                .setDeleteIntent(clearPendingIntent);


                Notification note = mBuilder.build();
        mainActivity.getNotificationManager().notify(BATTERY_NOTIFICATION_ID, note);

    }
}

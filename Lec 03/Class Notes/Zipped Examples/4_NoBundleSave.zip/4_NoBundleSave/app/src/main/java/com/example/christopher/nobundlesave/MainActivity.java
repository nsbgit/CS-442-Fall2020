package com.example.christopher.nobundlesave;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Log.d(TAG, "onCreate: " + savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void buttonClicked(View v) {
        EditText numText = findViewById(R.id.phoneNum);
        TextView output = findViewById(R.id.textView);
        String newText =  numText.getText().toString();
        String text = output.getText().toString();
        output.setText(String.format("%s\n%s", newText, text));
        numText.setText("");

    }


}

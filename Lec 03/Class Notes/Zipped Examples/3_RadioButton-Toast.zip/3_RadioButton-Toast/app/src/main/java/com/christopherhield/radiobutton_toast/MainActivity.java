package com.christopherhield.radiobutton_toast;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private TextView actionDisplay;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        actionDisplay = findViewById(R.id.actionDisplay);
    }

    public void radioClicked(View v) {
        String message = "Group 1: You Selected ";
        switch (v.getId()) {
            case R.id.androidButton:
                message += "Android";
                break;
            case R.id.iosButton:
                message += "iOS";
                break;
            case R.id.windowsButton:
                message += "Windows";
                break;
        }
        actionDisplay.setText(message);

    }

    public void radioClicked2(View v) {
        String message = "Group 2: You Selected ";
        switch (v.getId()) {
            case R.id.uberButton:
                message += "Uber";
                break;
            case R.id.lyftButton:
                message += "Lyft";
                break;
            case R.id.taxiButton:
                message += "Taxi";
                break;
        }

        actionDisplay.setText(message);
    }

}

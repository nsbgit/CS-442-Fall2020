package com.christopherhield.myapplication;

import android.content.Context;
import android.content.SharedPreferences;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private SharedPreferences myPrefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        myPrefs = getSharedPreferences("MY_PREFS", Context.MODE_PRIVATE);

        String myData = myPrefs.getString("DATA", "-----");

        ((TextView) findViewById(R.id.textView)).setText(myData);


    }

    public void copy(View v) {
        String s = ((EditText) findViewById(R.id.editText)).getText().toString();
        ((TextView) findViewById(R.id.textView)).setText(s);
        SharedPreferences.Editor prefsEditor = myPrefs.edit();
        prefsEditor.putString("DATA", s);
        prefsEditor.apply();
    }
}

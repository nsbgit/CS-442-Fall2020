package com.example.christopher.countries;

import java.io.Serializable;

class Country implements Serializable {
    // Serializable needed to add as extra to intent

    private String name;
    private String capital;
    private int population;
    private String region;
    private String subRegion;
    private int area;
    private String citizen;
    private String callingCodes;
    private String borders;

    Country(String nm, String cap, int pop, String reg, String sReg,
                   int ar, String cit, String cc, String bord) {
        name = nm;
        capital = cap;
        population = pop;
        region = reg;
        subRegion = sReg;
        area = ar;
        citizen = cit;
        callingCodes = cc;
        borders = bord;
    }

    String getBorders() {
        return borders;
    }

    String getCallingCodes() {
        return callingCodes;
    }

    int getArea() {
        return area;
    }

    String getCitizen() {
        return citizen;
    }

    String getName() {
        return name;
    }

    String getCapital() {
        return capital;
    }

    int getPopulation() {
        return population;
    }

    String getRegion() {
        return region;
    }

    String getSubRegion() {
        return subRegion;
    }
}
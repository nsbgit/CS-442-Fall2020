package com.example.christopher.weather;

import android.graphics.Bitmap;

class Weather {

    private String city;
    private String country;
    private String conditions;
    private String description;
    private String temp;
    private String humidity;
    private String wind;
    private String date;
    private Bitmap bitmap;

    Weather(String city, String country, String conditions, String description,
                   String temp, String humidity, String wind, String date, Bitmap bitmap) {
        this.city = city;
        this.country = country;
        this.conditions = conditions;
        this.description = description;
        this.temp = temp;
        this.humidity = humidity;
        this.wind = wind;
        this.date = date;
        this.bitmap = bitmap;
    }

    String getCity() {
        return city;
    }

    String getCountry() {
        return country;
    }

    String getConditions() {
        return conditions;
    }

    String getDescription() {
        return description;
    }

    String getTemp() {
        return temp;
    }

    String getHumidity() {
        return humidity;
    }

    String getWind() {
        return wind;
    }

    String getDate() {
        return date;
    }

    Bitmap getBitmap() {
        return bitmap;
    }
}

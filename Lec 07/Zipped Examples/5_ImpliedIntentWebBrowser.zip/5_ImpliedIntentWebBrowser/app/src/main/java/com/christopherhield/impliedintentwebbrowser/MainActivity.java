package com.christopherhield.impliedintentwebbrowser;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    private static final String cnnURL = "http://www.cnn.com";
    private static final String androidURL = "https://developer.android.com";
    private static final String googleURL = "http://www.google.com";
    private static final String tribURL = "https://www.chicagotribune.com/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void clickCNN(View v) {
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setData(Uri.parse(cnnURL));
        startActivity(i);
    }

    public void clickAndroid(View v) {
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setData(Uri.parse(androidURL));
        startActivity(i);
    }

    public void clickGoogle(View v) {
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setData(Uri.parse(googleURL));
        startActivity(i);
    }

    public void clickTrib(View v) {
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setData(Uri.parse(tribURL));
        startActivity(i);
    }

    @SuppressLint("SetJavaScriptEnabled")
    public void doStock(View v) {
        String symbol = ((EditText) findViewById(R.id.goToStock)).getText().toString();
        if (symbol.trim().isEmpty()) {
            return;
        }

        String url = "https://www.marketwatch.com/investing/stock/" + symbol;
        WebView webView = findViewById(R.id.webView);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.setWebViewClient(new WebViewClient());
        webView.loadUrl(Uri.parse(url).toString());
    }
}

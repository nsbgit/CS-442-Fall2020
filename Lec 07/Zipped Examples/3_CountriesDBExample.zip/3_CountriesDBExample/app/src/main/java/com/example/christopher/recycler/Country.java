package com.example.christopher.recycler;

import java.io.Serializable;

public class Country implements Serializable {

    private String name;
    private String capital;
    private int population;
    private String region;
    private String subRegion;

    Country(String nm, String cap, int pop, String reg, String sReg) {
        name = nm;
        capital = cap;
        population = pop;
        region = reg;
        subRegion = sReg;
    }

    public String getName() {
        return name;
    }

    String getCapital() {
        return capital;
    }

    int getPopulation() {
        return population;
    }

    String getRegion() {
        return region;
    }

    String getSubRegion() {
        return subRegion;
    }
}
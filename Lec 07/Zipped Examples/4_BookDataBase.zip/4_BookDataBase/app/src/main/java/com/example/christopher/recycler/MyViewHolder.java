package com.example.christopher.recycler;

import androidx.recyclerview.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

class MyViewHolder extends RecyclerView.ViewHolder {

    TextView title;
    TextView author;
    TextView isbn;
    TextView pubYear;
    TextView cost;

    MyViewHolder(View view) {
        super(view);
        title = view.findViewById(R.id.title);
        author = view.findViewById(R.id.author);
        isbn = view.findViewById(R.id.isbn);
        pubYear = view.findViewById(R.id.publisher_year);
        cost = view.findViewById(R.id.cost);
    }

}

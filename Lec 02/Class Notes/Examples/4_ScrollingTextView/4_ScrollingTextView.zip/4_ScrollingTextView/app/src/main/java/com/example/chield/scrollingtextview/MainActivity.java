package com.example.chield.scrollingtextview;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.widget.TextView;

import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private TextView textView1;
    private TextView textView2;
    private TextView textView3;

    private String text1 = "This is a one-line TextView";
    private String text2 = "This is a multi-line TextView without scrolling\n";
    private String text3 = "This is a multi-line TextView WITH scrolling\n";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // #1
        textView1 = findViewById(R.id.oneLine);
        textView1.setText(text1);

        // #2
        textView2 = findViewById(R.id.multiLine);
        StringBuilder sb = new StringBuilder(text2);
        for (int i = 0; i < 20; i++)
            sb.append(String.format(Locale.getDefault(), "Line #%d%n", i));
        textView2.setText(sb.toString());

        // #3
        textView3 = findViewById(R.id.multiLineScroll);

        // This next line is required for proper scrolling behavior
        textView3.setMovementMethod(new ScrollingMovementMethod());

        sb = new StringBuilder(text3);
        for (int i = 0; i < 20; i++)
            sb.append(String.format(Locale.getDefault(), "Line #%d%n", i));
        textView3.setText(sb.toString());

    }
}

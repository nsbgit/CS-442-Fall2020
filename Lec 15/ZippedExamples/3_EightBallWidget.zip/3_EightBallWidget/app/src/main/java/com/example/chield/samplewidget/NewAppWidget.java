package com.example.chield.samplewidget;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;

public class NewAppWidget extends AppWidgetProvider {

    public static final String WIDGET_WAS_CLICKED = "WIDGET_WAS_CLICKED";
    private boolean hadFirstClick = false;

    // Pre-defined set of 8-ball responses
    private static final String[] responses = new String[]{
            "It is certain",
            "It is decidedly so",
            "Without a doubt",
            "Yes definitely",
            "You may rely on it",
            "As I see it, yes",
            "Most likely",
            "Outlook good",
            "Yes",
            "Signs point to yes",
            "Reply hazy try again",
            "Ask again later",
            "Better not tell you now",
            "Cannot predict now",
            "Concentrate and ask again",
            "Don't count on it",
            "My reply is no",
            "My sources say no",
            "Outlook not so good",
            "Very doubtful"
    };

    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);

        // No timer here - only touches/clicks
        if (intent.getAction() != null &&
                (intent.getAction().equals(WIDGET_WAS_CLICKED) ||
                        intent.getAction().equals("android.appwidget.action.APPWIDGET_UPDATE"))) {

            // Before the first click, the text should not change - using hadFirstClick to determine
            if (intent.getAction().equals(WIDGET_WAS_CLICKED))
                hadFirstClick = true;

            // Get widget view
            RemoteViews remoteViews = new RemoteViews(context.getPackageName(), R.layout.new_app_widget);

            // If has been clicked already, change text
            if (hadFirstClick) {
                // Pick a random response
                int idx = (int) (Math.random() * responses.length);
                String choice = responses[idx];
                remoteViews.setTextViewText(R.id.appwidget_text, choice);
            }
            remoteViews.setImageViewResource(R.id.imageView2, R.drawable.eight_ball);



            // Set up pending intent for next click
            Intent newIntent = new Intent(context, NewAppWidget.class);
            newIntent.setAction(WIDGET_WAS_CLICKED);
            PendingIntent pi = PendingIntent.getBroadcast(context, 0, newIntent, 0);
            remoteViews.setOnClickPendingIntent(R.id.layout, pi);

            // Update the widget
            ComponentName componentName = new ComponentName(context, NewAppWidget.class);
            AppWidgetManager appWidgetManager = AppWidgetManager.getInstance(context);
            appWidgetManager.updateAppWidget(componentName, remoteViews);
        }
    }
/*
    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        Log.d(TAG, "onUpdate: ");
        // Auto-called when app is touched

        // There may be multiple widgets active, so update all of them
        for (int appWidgetId : appWidgetIds) {
            updateAppWidget(context, appWidgetManager, appWidgetId);
        }
    }

    static void updateAppWidget(Context context, AppWidgetManager appWidgetManager,
                                int appWidgetId) {

        Log.d(TAG, "updateAppWidget: ");
        CharSequence widgetText = context.getString(R.string.appwidget_text);

        // Construct the RemoteViews object
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.new_app_widget);
        views.setTextViewText(R.id.appwidget_text, widgetText);


        // Instruct the widget manager to update the widget
        appWidgetManager.updateAppWidget(appWidgetId, views);
    }
*/
    @Override
    public void onEnabled(Context context) {
        // Enter relevant functionality for when the first widget is created
        // Nothing to do here
    }

    @Override
    public void onDisabled(Context context) {
        // Enter relevant functionality for when the last widget is disabled
        // Nothing to do here
    }
}

